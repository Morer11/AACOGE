import React, { useState, useEffect } from 'react';
import { BrowserRouter, Routes, Route, Navigate, Link } from 'react-router-dom';
import Login from './components/Login';
import Register from './components/Register';
import ProjectList from './components/ProjectList';
import ProjectEditor from './components/ProjectEditor';
import AdminPanel from './components/AdminPanel';

function Logo() {
  return (
    <svg
      className="w-10 h-10 text-yellow-400"
      fill="none"
      stroke="currentColor"
      strokeWidth="2"
      viewBox="0 0 24 24"
      strokeLinecap="round"
      strokeLinejoin="round"
      aria-hidden="true"
    >
      <path d="M12 2L2 7l10 5 10-5-10-5z" />
      <path d="M2 17l10 5 10-5" />
      <path d="M2 12l10 5 10-5" />
    </svg>
  );
}

function App() {
  const [token, setToken] = useState(localStorage.getItem('token'));

  const logout = () => {
    setToken(null);
    localStorage.removeItem('token');
  };

  return (
    <BrowserRouter>
      <div className="min-h-screen flex flex-col bg-gradient-to-br from-blue-50 to-indigo-100">
        <header className="bg-gradient-to-r from-indigo-600 via-purple-600 to-pink-600 text-white p-4 flex justify-between items-center shadow-lg">
          <Link to="/projects" className="flex items-center space-x-3 hover:opacity-90">
            <Logo />
            <span className="text-3xl font-extrabold tracking-tight select-none">AACOGE</span>
          </Link>
          <nav>
            {token ? (
              <button
                onClick={logout}
                className="bg-white text-indigo-600 font-semibold px-4 py-2 rounded shadow hover:bg-indigo-50 transition"
                aria-label="Logout"
              >
                Logout
              </button>
            ) : (
              <div className="space-x-6 text-lg font-medium">
                <Link to="/login" className="hover:underline hover:text-indigo-200">
                  Login
                </Link>
                <Link to="/register" className="hover:underline hover:text-indigo-200">
                  Register
                </Link>
              </div>
            )}
          </nav>
        </header>

        <main className="flex-grow container mx-auto p-6">
          <Routes>
            <Route path="/" element={<Navigate to={token ? "/projects" : "/login"} />} />
            <Route path="/login" element={<Login setToken={setToken} />} />
            <Route path="/register" element={<Register />} />
            <Route path="/projects" element={token ? <ProjectList token={token} /> : <Navigate to="/login" />} />
            <Route path="/projects/:id" element={token ? <ProjectEditor token={token} /> : <Navigate to="/login" />} />
            <Route path="/admin" element={token ? <AdminPanel token={token} /> : <Navigate to="/login" />} />
          </Routes>
        </main>

        <footer className="bg-indigo-700 text-indigo-100 p-4 text-center font-light select-none">
          &copy; 2024 AACOGE - AI Website Generator Powered by OpenAI
        </footer>
      </div>
    </BrowserRouter>
  );
}

export default App;

