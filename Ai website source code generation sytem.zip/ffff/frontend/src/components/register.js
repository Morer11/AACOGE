import React, { useState } from 'react';
import { apiPost } from '../api';
import { useNavigate } from 'react-router-dom';

const Register = () => {
  const [username, setUsername] = useState('');
  const [password, setPassword] = useState('');
  const [message, setMessage] = useState('');
  const navigate = useNavigate();

  const submit = async e => {
    e.preventDefault();
    try {
      await apiPost('/auth/register', { username, password });
      setMessage('User registered successfully! Please login.');
      setTimeout(() => navigate('/login'), 2000);
    } catch {
      setMessage('Error registering user.');
    }
  };

  return (
    <div className="max-w-md mx-auto bg-white p-8 rounded shadow">
      <h1 className="text-2xl mb-4 font-semibold">Register</h1>
      {message && <div className="text-green-600 mb-2">{message}</div>}
      <form onSubmit={submit} className="space-y-4">
        <input
          type="text"
          placeholder="Username"
          value={username}
          onChange={e => setUsername(e.target.value)}
          className="w-full border rounded p-2"
          required
        />
        <input
          type="password"
          placeholder="Password"
          value={password}
          onChange={e => setPassword(e.target.value)}
          className="w-full border rounded p-2"
          required
        />
        <button className="bg-blue-600 text-white px-4 py-2 rounded w-full" type="submit">
          Register
        </button>
      </form>
    </div>
  );
};

export default Register;
