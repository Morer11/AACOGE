import React, { useEffect, useState, useRef } from 'react';
import { apiGet, apiPost } from '../api';
import { downloadCode } from '../utils/download';
import { useParams } from 'react-router-dom';

const frameworks = [
  { label: 'Vanilla HTML/CSS/JS', value: 'vanilla' },
  { label: 'React', value: 'react' },
  { label: 'Vue', value: 'vue' },
];

const ProjectEditor = ({ token }) => {
  const { id } = useParams();
  const [project, setProject] = useState(null);
  const [language, setLanguage] = useState('vanilla');
  const [code, setCode] = useState('');
  const [loading, setLoading] = useState(false);
  const iframeRef = useRef(null);

  useEffect(() => {
    fetchProject();
  }, []);

  const fetchProject = async () => {
    const data = await apiGet(`/projects`, token);
    const p = data.find(pr => pr._id === id);
    if (p) {
      setProject(p);
      setCode(p.code || '');
    }
  };

  const generateCode = async () => {
    if (!project) return;
    setLoading(true);
    try {
      const response = await apiPost(`/projects/${id}/generate`, {
        language,
      }, token);
      if (response.code) {
        setCode(response.code);
      }
    } catch (e) {
      alert('Error generating code');
    }
    setLoading(false);
  };

  // Update live preview in iframe
  useEffect(() => {
    if (iframeRef.current) {
      const doc = iframeRef.current.contentDocument || iframeRef.current.contentWindow.document;
      doc.open();
      doc.write(code);
      doc.close();
    }
  }, [code]);

  const download = () => {
    downloadCode(`${project.title || 'website'}.html`, code);
  };

  if (!project) return <p>Loading project...</p>;

  return (
    <div className="space-y-4">
      <h1 className="text-3xl font-bold">{project.title}</h1>
      <p className="text-gray-600">{project.description}</p>

      <div className="flex items-center gap-4">
        <label htmlFor="language" className="font-semibold">
          Select Framework/Language:
        </label>
        <select
          id="language"
          value={language}
          onChange={e => setLanguage(e.target.value)}
          className="border rounded p-2"
        >
          {frameworks.map(fw => (
            <option key={fw.value} value={fw.value}>{fw.label}</option>
          ))}
        </select>
        <button
          onClick={generateCode}
          disabled={loading}
          className="bg-blue-600 text-white px-4 py-2 rounded disabled:opacity-50"
        >
          {loading ? 'Generating...' : 'Generate Website'}
        </button>
        <button onClick={download} className="bg-green-600 text-white px-4 py-2 rounded">
          Download Code
        </button>
      </div>

      <div className="border rounded overflow-hidden" style={{ height: '500px' }}>
        <iframe
          title="Live preview"
          ref={iframeRef}
          sandbox="allow-scripts allow-same-origin"
          style={{ width: '100%', height: '100%', border: 'none' }}
        />
      </div>

      <details>
        <summary className="cursor-pointer font-semibold mt-4 mb-2">View Generated Code</summary>
        <pre className="bg-gray-800 text-green-300 p-4 rounded max-h-96 overflow-auto whitespace-pre-wrap">
          {code}
        </pre>
      </details>
    </div>
  );
};

export default ProjectEditor;
