import React, { useState, useEffect } from 'react';
import { apiGet, apiPost } from '../api';
import { Link, useNavigate } from 'react-router-dom';

const ProjectList = ({ token }) => {
  const [projects, setProjects] = useState([]);
  const [newTitle, setNewTitle] = useState('');
  const [newDescription, setNewDescription] = useState('');
  const navigate = useNavigate();

  useEffect(() => {
    fetchProjects();
  }, []);

  const fetchProjects = async () => {
    const data = await apiGet('/projects', token);
    setProjects(data);
  };

  const createProject = async e => {
    e.preventDefault();
    if (!newTitle) return;
    const project = await apiPost('/projects', { title: newTitle, description: newDescription }, token);
    setNewTitle('');
    setNewDescription('');
    navigate(`/projects/${project._id}`);
  };

  return (
    <div>
      <h1 className="text-3xl font-bold mb-6">Your Projects</h1>
      <form onSubmit={createProject} className="mb-6 space-y-2">
        <input
          type="text"
          placeholder="Project Title"
          className="border p-2 rounded w-full"
          value={newTitle}
          onChange={e => setNewTitle(e.target.value)}
          required
        />
        <textarea
          placeholder="Project Description (what your website should do)"
          className="border p-2 rounded w-full"
          value={newDescription}
          onChange={e => setNewDescription(e.target.value)}
          rows={3}
        />
        <button className="bg-green-600 text-white px-4 py-2 rounded" type="submit">
          Create Project
        </button>
      </form>
      <ul className="space-y-3">
        {projects.length === 0 && <p>You have no projects yet.</p>}
        {projects.map(project => (
          <li key={project._id}>
            <Link
              to={`/projects/${project._id}`}
              className="block p-4 bg-white rounded shadow hover:bg-gray-50"
            >
              <h2 className="text-xl font-semibold">{project.title}</h2>
              <p className="text-gray-600">{project.description}</p>
            </Link>
          </li>
        ))}
      </ul>
    </div>
  );
};

export default ProjectList;
