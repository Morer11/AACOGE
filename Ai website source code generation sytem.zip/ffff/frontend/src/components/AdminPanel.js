import React from 'react';

const AdminPanel = () => {
  // Placeholder for admin features like user management, template management etc.
  return (
    <div>
      <h1 className="text-3xl font-bold mb-6">Admin Panel</h1>
      <p>This area is under development.</p>
    </div>
  );
};

export default AdminPanel;
