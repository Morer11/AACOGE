const User = require('../models/User');

// A simple isAdmin middleware assumes you have an isAdmin flag on User model.
// If you don't have this, you may define admin users list by ID or username here.

const isAdminMiddleware = async (req, res, next) => {
  try {
    const user = await User.findById(req.user.id);
    if (!user) return res.status(401).json({ message: 'Unauthorized' });

    if (!user.isAdmin) {
      return res.status(403).json({ message: 'Forbidden: Admins only' });
    }

    next();
  } catch (err) {
    console.error('Admin auth error:', err);
    res.status(500).json({ message: 'Server error' });
  }
};

module.exports = isAdminMiddleware;
