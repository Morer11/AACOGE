const express = require('express');
const Project = require('../models/Project');
const { generateCode } = require('../utils/openai');
const router = express.Router();
const authMiddleware = require('../middleware/authMiddleware');

// Create a new project
router.post('/', authMiddleware, async (req, res) => {
    const { title, description } = req.body;
    const project = new Project({ userId: req.user.id, title, description });
    await project.save();
    res.status(201).json(project);
});

// Generate code for a project
router.post('/:id/generate', authMiddleware, async (req, res) => {
    const project = await Project.findById(req.params.id);
    if (!project) return res.status(404).send('Project not found');

    const code = await generateCode(project.description);
    project.code = code;
    await project.save();
    res.json({ code });
});

// Get all projects for a user
router.get('/', authMiddleware, async (req, res) => {
    const projects = await Project.find({ userId: req.user.id });
    res.json(projects);
});

module.exports = router;
