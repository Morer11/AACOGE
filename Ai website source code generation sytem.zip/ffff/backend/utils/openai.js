const { Configuration, OpenAIApi } = require('openai');

const configuration = new Configuration({
    apiKey: process.env.OPENAI_API_KEY,
});
const openai = new OpenAIApi(configuration);

const generateCode = async (description) => {
    const response = await openai.createCompletion({
        model: "text-davinci-003",
        prompt: `Generate a complete website source code based on the following description: ${description}`,
        max_tokens: 1500,
    });
    return response.data.choices[0].text.trim();
};

module.exports = { generateCode };
