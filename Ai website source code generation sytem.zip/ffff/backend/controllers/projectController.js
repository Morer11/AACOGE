// This file can be used for more complex logic related to projects if needed
// This file can be used for more complex logic related to authentication if needed
const Project = require('../models/Project');
const { generateCode } = require('../utils/openai');
const { securityScan } = require('../utils/securityScan');

// Create a new project
const createProject = async (req, res) => {
  try {
    const { title, description } = req.body;
    if (!title) return res.status(400).json({ message: 'Title is required' });

    const project = new Project({
      userId: req.user.id,
      title,
      description: description || ''
    });

    await project.save();
    res.status(201).json(project);
  } catch (error) {
    console.error('Error creating project:', error);
    res.status(500).json({ message: 'Server error' });
  }
};

// Get all projects for a user
const getProjects = async (req, res) => {
  try {
    const projects = await Project.find({ userId: req.user.id }).sort({ createdAt: -1 });
    res.json(projects);
  } catch (error) {
    console.error('Error fetching projects:', error);
    res.status(500).json({ message: 'Server error' });
  }
};

// Get a single project by ID
const getProjectById = async (req, res) => {
  try {
    const project = await Project.findOne({ _id: req.params.id, userId: req.user.id });
    if (!project) return res.status(404).json({ message: 'Project not found' });
    res.json(project);
  } catch (error) {
    console.error('Error fetching project:', error);
    res.status(500).json({ message: 'Server error' });
  }
};

// Generate website code for a project using AI
const generateProjectCode = async (req, res) => {
  try {
    const project = await Project.findOne({ _id: req.params.id, userId: req.user.id });
    if (!project) return res.status(404).json({ message: 'Project not found' });

    const { description, language } = req.body;
    // If description is provided in body, update it for generation
    if (description) project.description = description;

    // Prepare prompt for AI generation including language
    const prompt = `
Generate a complete, high-quality, and downloadable website source code using ${language || 'Vanilla HTML/CSS/JS'}, 
based on this description: ${project.description}
Provide complete code including HTML, CSS, and JavaScript as appropriate.
    `.trim();

    const code = await generateCode(prompt);

    // Optional: run security scan on generated code
    const isSafe = securityScan(code);
    if (!isSafe) {
      return res.status(400).json({ message: 'Generated code failed security checks' });
    }

    project.code = code;
    await project.save();

    res.json({ code });
  } catch (error) {
    console.error('Error generating project code:', error);
    res.status(500).json({ message: 'Server error' });
  }
};

// Update project details
const updateProject = async (req, res) => {
  try {
    const updates = req.body;
    const project = await Project.findOneAndUpdate(
      { _id: req.params.id, userId: req.user.id },
      updates,
      { new: true }
    );
    if (!project) return res.status(404).json({ message: 'Project not found' });
    res.json(project);
  } catch (error) {
    console.error('Error updating project:', error);
    res.status(500).json({ message: 'Server error' });
  }
};

// Delete a project
const deleteProject = async (req, res) => {
  try {
    const project = await Project.findOneAndDelete({ _id: req.params.id, userId: req.user.id });
    if (!project) return res.status(404).json({ message: 'Project not found' });
    res.json({ message: 'Project deleted successfully' });
  } catch (error) {
    console.error('Error deleting project:', error);
    res.status(500).json({ message: 'Server error' });
  }
};

module.exports = {
  createProject,
  getProjects,
  getProjectById,
  generateProjectCode,
  updateProject,
  deleteProject,
};

